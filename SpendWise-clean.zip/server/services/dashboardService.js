const pool = require("../config/db");

async function getDashboardSummary(userId, year, month) {
  // 1. Set the selected date range.
  const selectedYear = Number(year);
  const selectedMonth = month === "all" ? "all" : Number(month);

  let startDate;
  let endDate;

  if (selectedMonth === "all") {
    startDate = `${selectedYear}-01-01`;
    endDate = `${selectedYear + 1}-01-01`;
  } else {
    startDate = `${selectedYear}-${String(selectedMonth).padStart(2, "0")}-01`;

    const nextMonth = new Date(selectedYear, selectedMonth, 1);

    endDate = `${nextMonth.getFullYear()}-${String(
      nextMonth.getMonth() + 1,
    ).padStart(2, "0")}-01`;
  }

  const [
    totalsResult,
    balanceResult,
    categoryResult,
    recentResult,
    monthlyExpensesResult,
  ] = await Promise.all([
    // 2. Income and expenses for the selected period.
    pool.query(
      `SELECT
         COALESCE(SUM(amount) FILTER (
           WHERE type = 'income'
         ), 0)::numeric(12, 2)::text AS "totalIncome",

         COALESCE(SUM(amount) FILTER (
           WHERE type = 'expense'
         ), 0)::numeric(12, 2)::text AS "totalExpenses"

       FROM transactions
       WHERE user_id = $1
         AND transaction_date >= $2
         AND transaction_date < $3`,
      [userId, startDate, endDate],
    ),

    // 3. Accumulated balance up to the selected period's end.
    pool.query(
      `SELECT
         (
           COALESCE(SUM(amount) FILTER (
             WHERE type = 'income'
           ), 0)
           -
           COALESCE(SUM(amount) FILTER (
             WHERE type = 'expense'
           ), 0)
         )::numeric(12, 2)::text AS "totalBalance"

       FROM transactions
       WHERE user_id = $1
         AND transaction_date < $2`,
      [userId, endDate],
    ),

    // 4. Expenses grouped by category for the selected period.
    pool.query(
      `SELECT
         category,
         SUM(amount)::numeric(12, 2)::text AS "totalAmount"

       FROM transactions
       WHERE user_id = $1
         AND type = 'expense'
         AND transaction_date >= $2
         AND transaction_date < $3

       GROUP BY category
       ORDER BY SUM(amount) DESC`,
      [userId, startDate, endDate],
    ),

    // 5. Five most recent transactions in the selected period.
    pool.query(
      `SELECT
         id,
         title,
         amount::text AS amount,
         type,
         category,
         transaction_date AS "transactionDate"

       FROM transactions
       WHERE user_id = $1
         AND transaction_date >= $2
         AND transaction_date < $3

       ORDER BY transaction_date DESC, id DESC
       LIMIT 5`,
      [userId, startDate, endDate],
    ),

    // 6. Monthly expenses for the full-year chart.
    pool.query(
      `SELECT
  TO_CHAR(months.month, 'YYYY-MM-DD') AS month,
  COALESCE(SUM(t.amount), 0)::numeric(12, 2)::text
    AS "totalExpenses"

       FROM generate_series(
         $2::date,
         ($3::date - INTERVAL '1 month')::date,
         INTERVAL '1 month'
       ) AS months(month)

       LEFT JOIN transactions t
         ON t.user_id = $1
         AND t.type = 'expense'
         AND t.transaction_date >= months.month
         AND t.transaction_date <
             (months.month + INTERVAL '1 month')

       GROUP BY months.month
       ORDER BY months.month`,
      [userId, startDate, endDate],
    ),
  ]);

  const totals = totalsResult.rows[0];
  const balance = balanceResult.rows[0];

  return {
    period: {
      year: selectedYear,
      month: selectedMonth,
      startDate,
      endDate,
    },

    summary: {
      totalIncome: totals.totalIncome,
      totalExpenses: totals.totalExpenses,
      totalBalance: (
        Number(totals.totalIncome) - Number(totals.totalExpenses)
      ).toFixed(2),
    },

    // Used for the income remaining percentage.
    monthly: {
      income: totals.totalIncome,
      expenses: totals.totalExpenses,
    },

    expensesByCategory: categoryResult.rows,
    recentTransactions: recentResult.rows,

    // Used by the annual expense chart.
    monthlyExpenses: monthlyExpensesResult.rows,
  };
}

module.exports = { getDashboardSummary };
